#internal not exported
reducer <- 
function(x) gsub("\\s+", " ", x)
